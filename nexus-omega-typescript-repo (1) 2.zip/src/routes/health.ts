import type { Request, Response } from "express";
import { getLastEvaluation } from "./evaluate.js";

export async function getHealth(_req: Request, res: Response): Promise<void> {
  res.json({
    ok: true,
    version: "v0.4.2-hardened",
    lastEvaluation: getLastEvaluation() ?? null
  });
}
