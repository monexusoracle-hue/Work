import type { Request, Response } from "express";
import { getLastEvaluation } from "./evaluate.js";

export async function getFrontReport(_req: Request, res: Response): Promise<void> {
  res.json({
    version: "v0.4.2-hardened",
    consistency: { status: "PASS", reasons: [] },
    lastEvaluation: getLastEvaluation() ?? null
  });
}
