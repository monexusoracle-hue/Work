import type { Request, Response } from "express";
import { evaluateEnvelope } from "../lib/omega-api/envelope/evaluate.js";
import { checkIdempotence } from "../lib/omega-api/idempotence.js";
import { recordReplayCase } from "../lib/omega-api/replay-harness.js";

let lastEvaluation: string | undefined;

export async function postEvaluate(req: Request, res: Response): Promise<void> {
  const body = req.body;
  const result = await evaluateEnvelope(body);
  checkIdempotence("/api/v1/envelope/evaluate", body, result);
  lastEvaluation = result.evaluatedAt;
  recordReplayCase(`evaluate-${Date.now()}`, {
    route: "/api/v1/envelope/evaluate",
    request: body,
    response: result
  });
  res.json(result);
}

export function getLastEvaluation(): string | undefined {
  return lastEvaluation;
}
