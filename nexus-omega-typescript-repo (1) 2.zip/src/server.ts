import express from "express";
import { postEvaluate } from "./routes/evaluate.js";
import { getFrontReport } from "./routes/front-report.js";
import { getHealth } from "./routes/health.js";

const app = express();
app.use(express.json());

app.post("/api/v1/envelope/evaluate", postEvaluate);
app.get("/api/v1/envelope/front-report", getFrontReport);
app.get("/omega-api/health", getHealth);

const port = process.env.PORT ? Number(process.env.PORT) : 3000;
app.listen(port, () => {
  console.log(`nexus-omega-typescript listening on :${port}`);
});
