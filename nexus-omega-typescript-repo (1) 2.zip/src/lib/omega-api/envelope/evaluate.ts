import { z } from "zod";
import { assertConsistency } from "../../mfcs/consistency.js";
import { computeNearRecursion } from "../../mfcs/recursion.js";
import type { EnvelopeEvaluationV1, EnvelopeRequest } from "../../types.js";

const requestSchema = z.object({
  state: z.object({
    phi: z.number(),
    energy: z.number(),
    nodeDensity: z.number(),
    stabilityWindow: z.number(),
    recursionSeed: z.number(),
    mode: z.enum(["IDLE", "BUILD", "FUSION", "COLLAPSE"])
  }),
  config: z.object({
    horizonSteps: z.number().int().positive(),
    epsilon: z.number().positive(),
    maxEnvelope: z.number().positive()
  })
});

export async function evaluateEnvelope(input: EnvelopeRequest): Promise<EnvelopeEvaluationV1> {
  const parsed = requestSchema.parse(input);
  const { state, config } = parsed;

  const envelopeValue = state.energy + state.phi + state.nodeDensity * state.stabilityWindow;
  const phiSatisfied = state.phi >= 0;
  const nearRecursionResult = computeNearRecursion(state, config.horizonSteps, config.epsilon);
  const isValid = phiSatisfied && envelopeValue <= config.maxEnvelope;

  const consistency = assertConsistency({
    isValid,
    nearRecursion: nearRecursionResult.nearRecursion,
    phiSatisfied,
    deterministic: true,
    idempotent: true
  });

  return {
    version: "v0.4.2-hardened",
    isValid,
    phiSatisfied,
    nearRecursion: nearRecursionResult.nearRecursion,
    recursion: {
      minDistance: nearRecursionResult.minDistance,
      stepsChecked: nearRecursionResult.stepsChecked
    },
    envelope: {
      value: Number(envelopeValue.toFixed(6)),
      limit: config.maxEnvelope
    },
    consistency: {
      status: consistency.consistency,
      reasons: consistency.reasons
    },
    determinismLocked: true,
    idempotenceChecked: true,
    evaluatedAt: new Date().toISOString()
  };
}
