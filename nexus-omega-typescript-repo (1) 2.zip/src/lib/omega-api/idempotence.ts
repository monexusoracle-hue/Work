import crypto from "node:crypto";

type CacheValue = {
  hash: string;
  timestamp: number;
};

const responseCache = new Map<string, CacheValue>();
const TTL_MS = 5 * 60 * 1000;

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
  const entries = Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b));
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${stableStringify(v)}`).join(",")}}`;
}

function hashValue(value: unknown): string {
  return crypto.createHash("sha256").update(stableStringify(value)).digest("hex");
}

export function checkIdempotence(route: string, payload: unknown, responseBody: unknown): void {
  const now = Date.now();
  const key = `${route}:${hashValue(payload)}`;
  const responseHash = hashValue(responseBody);
  const existing = responseCache.get(key);

  if (existing && now - existing.timestamp < TTL_MS && existing.hash !== responseHash) {
    throw new Error("IDEMPOTENCE_VIOLATION");
  }

  responseCache.set(key, { hash: responseHash, timestamp: now });
}
