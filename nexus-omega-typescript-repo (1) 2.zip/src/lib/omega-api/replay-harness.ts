import { mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

export interface ReplayCase {
  route: string;
  request: unknown;
  response: unknown;
}

const ROOT = join(process.cwd(), ".omega-replay");

export function recordReplayCase(name: string, entry: ReplayCase): void {
  mkdirSync(ROOT, { recursive: true });
  writeFileSync(join(ROOT, `${name}.json`), JSON.stringify(entry, null, 2), "utf8");
}

export function loadReplayCases(): ReplayCase[] {
  mkdirSync(ROOT, { recursive: true });
  return readdirSync(ROOT)
    .filter((f) => f.endsWith(".json"))
    .map((f) => JSON.parse(readFileSync(join(ROOT, f), "utf8")) as ReplayCase);
}
