export type Mode = "IDLE" | "BUILD" | "FUSION" | "COLLAPSE";

export interface EnvelopeState {
  phi: number;
  energy: number;
  nodeDensity: number;
  stabilityWindow: number;
  recursionSeed: number;
  mode: Mode;
}

export interface EnvelopeConfig {
  horizonSteps: number;
  epsilon: number;
  maxEnvelope: number;
}

export interface EnvelopeRequest {
  state: EnvelopeState;
  config: EnvelopeConfig;
}

export interface NearRecursionResult {
  nearRecursion: boolean;
  minDistance: number;
  stepsChecked: number;
}

export interface EnvelopeEvaluationV1 {
  version: "v0.4.2-hardened";
  isValid: boolean;
  phiSatisfied: boolean;
  nearRecursion: boolean;
  recursion: {
    minDistance: number;
    stepsChecked: number;
  };
  envelope: {
    value: number;
    limit: number;
  };
  consistency: {
    status: "PASS" | "FAIL";
    reasons: string[];
  };
  determinismLocked: boolean;
  idempotenceChecked: boolean;
  evaluatedAt: string;
  lastEvaluation?: string;
}
