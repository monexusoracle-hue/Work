export type ConsistencyStatus = "PASS" | "FAIL";

export interface ConsistencyInput {
  isValid: boolean;
  nearRecursion: boolean;
  phiSatisfied: boolean;
  deterministic?: boolean;
  idempotent?: boolean;
}

export interface ConsistencyCheck {
  consistency: ConsistencyStatus;
  reasons: string[];
}

export function deriveConsistency(input: ConsistencyInput): ConsistencyCheck {
  const reasons: string[] = [];
  if (input.isValid && input.nearRecursion && !input.phiSatisfied) {
    reasons.push("VALID_AND_NEAR_RECURSIVE_BUT_PHI_FALSE");
  }
  if (input.deterministic === false) reasons.push("DETERMINISM_LOCK_FAILED");
  if (input.idempotent === false) reasons.push("IDEMPOTENCE_FAILED");

  return {
    consistency: reasons.length === 0 ? "PASS" : "FAIL",
    reasons
  };
}

export function assertConsistency(input: ConsistencyInput): ConsistencyCheck {
  const check = deriveConsistency(input);
  if (check.consistency === "FAIL") {
    throw new Error(`CONSISTENCY_FAIL:${check.reasons.join(",")}`);
  }
  return check;
}
