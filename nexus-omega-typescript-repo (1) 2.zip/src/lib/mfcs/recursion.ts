import type { EnvelopeState, NearRecursionResult } from "../types.js";

export function distance(a: EnvelopeState, b: EnvelopeState): number {
  return (
    Math.abs(a.phi - b.phi) +
    Math.abs(a.energy - b.energy) +
    Math.abs(a.nodeDensity - b.nodeDensity) +
    Math.abs(a.stabilityWindow - b.stabilityWindow)
  );
}

export function stepState(state: EnvelopeState): EnvelopeState {
  // deterministic evolution for the runtime truth of ≈↻
  return {
    ...state,
    phi: state.phi + 0.1 * state.nodeDensity - 0.05 * state.energy,
    energy: Math.max(0, state.energy + 0.05 * state.stabilityWindow - 0.02 * state.phi),
    nodeDensity: Math.max(0, state.nodeDensity * 0.995 + 0.001 * state.recursionSeed),
    stabilityWindow: Math.max(0, state.stabilityWindow * 0.998 + 0.01)
  };
}

export function computeNearRecursion(initial: EnvelopeState, horizonSteps: number, epsilon: number): NearRecursionResult {
  let current = { ...initial };
  let minDistance = Number.POSITIVE_INFINITY;
  let nearRecursion = false;

  for (let i = 1; i <= horizonSteps; i += 1) {
    current = stepState(current);
    const d = distance(initial, current);
    minDistance = Math.min(minDistance, d);
    if (d <= epsilon) {
      nearRecursion = true;
      break;
    }
  }

  return { nearRecursion, minDistance, stepsChecked: horizonSteps };
}
