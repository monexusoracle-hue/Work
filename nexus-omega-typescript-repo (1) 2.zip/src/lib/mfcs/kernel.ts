export type State = "IDLE" | "EVAL" | "EXEC";

export interface Invariants {
  T1_order(history: State[]): boolean;
  T2_timing(ctx: Record<string, unknown>): boolean;
  T3_continuity(history: State[]): boolean;
  M1_stability(ctx: Record<string, unknown>): boolean;
  M2_coherence(ctx: Record<string, unknown>): boolean;
  M4_emergence(proposal: DecisionOption): boolean;
}

export interface Vessel {
  state: State;
  context: Record<string, unknown>;
  history: State[];
  invariants: Invariants;
}

export interface DecisionOption {
  id: string;
  payload: Record<string, unknown>;
}

export interface InvariantReport {
  passed: boolean;
  status: "PASS" | "FAIL";
  violations: string[];
}

export interface DecisionResult {
  chosen: DecisionOption | null;
  trace: State[];
  invariantReport: InvariantReport;
}

export const defaultInvariants: Invariants = {
  T1_order: (history) => history.every((s) => ["IDLE", "EVAL", "EXEC"].includes(s)),
  T2_timing: (ctx) => typeof ctx.time_available_min === "number" && ctx.time_available_min > 0,
  T3_continuity: (history) => {
    const valid = new Set(["IDLE>EVAL", "EVAL>EXEC", "EXEC>IDLE", "EVAL>IDLE"]);
    for (let i = 0; i < history.length - 1; i += 1) {
      if (!valid.has(`${history[i]}>${history[i + 1]}`)) return false;
    }
    return true;
  },
  M1_stability: (ctx) => ctx.signalIntegrity !== "INTERFERENCE",
  M2_coherence: (ctx) => typeof ctx.score === "number",
  M4_emergence: (proposal) => proposal.payload.allowed !== false
};

export const initialVessel: Vessel = {
  state: "IDLE",
  context: {},
  history: [],
  invariants: defaultInvariants
};

function buildInvariantReport(violations: string[]): InvariantReport {
  return {
    passed: violations.length === 0,
    status: violations.length === 0 ? "PASS" : "FAIL",
    violations
  };
}

export function anchor(v: Vessel, ctx: Record<string, unknown>): Vessel {
  return { ...v, state: "IDLE", context: ctx };
}

export function evaluate(v: Vessel, options: DecisionOption[]): DecisionOption[] {
  if (!v.invariants.T2_timing(v.context)) return [];
  return options.filter((o) => v.invariants.M4_emergence(o));
}

export function harmonize(v: Vessel, options: DecisionOption[]): DecisionOption | null {
  if (!v.invariants.M2_coherence(v.context)) return null;
  return options[0] ?? null;
}

export function decide(v: Vessel, ctx: Record<string, unknown>, options: DecisionOption[]): DecisionResult {
  const violations: string[] = [];
  const anchored = anchor(v, ctx);
  const filtered = evaluate(anchored, options);
  const chosen = harmonize(anchored, filtered);

  const trace: State[] = chosen ? ["EVAL", "EXEC", "IDLE"] : ["EVAL", "IDLE"];

  if (!anchored.invariants.T1_order(trace)) violations.push("T1_ORDER_VIOLATION");
  if (!anchored.invariants.T3_continuity(trace)) violations.push("T3_CONTINUITY_VIOLATION");
  if (!anchored.invariants.M1_stability(anchored.context)) violations.push("M1_STABILITY_VIOLATION");
  if (!anchored.invariants.M2_coherence(anchored.context)) violations.push("M2_COHERENCE_VIOLATION");

  return {
    chosen,
    trace,
    invariantReport: buildInvariantReport(violations)
  };
}
