import { describe, expect, it } from "vitest";
import { checkIdempotence } from "../src/lib/omega-api/idempotence.js";

describe("idempotence", () => {
  it("accepts same response for same request", () => {
    const payload = { a: 1 };
    const response = { ok: true };
    expect(() => checkIdempotence("/route", payload, response)).not.toThrow();
    expect(() => checkIdempotence("/route", payload, response)).not.toThrow();
  });

  it("rejects divergent response for same request", () => {
    const payload = { a: 2 };
    checkIdempotence("/route2", payload, { ok: true });
    expect(() => checkIdempotence("/route2", payload, { ok: false })).toThrow("IDEMPOTENCE_VIOLATION");
  });
});
