import { describe, expect, it } from "vitest";
import { evaluateEnvelope } from "../src/lib/omega-api/envelope/evaluate.js";
import type { EnvelopeRequest } from "../src/lib/types.js";

const fixedInput: EnvelopeRequest = {
  state: {
    phi: 0.618,
    energy: 1.0,
    nodeDensity: 1.2,
    stabilityWindow: 2.618,
    recursionSeed: 4,
    mode: "BUILD"
  },
  config: {
    horizonSteps: 8,
    epsilon: 0.001,
    maxEnvelope: 20
  }
};

describe("determinism lock", () => {
  it("same input produces the same output 50 times", async () => {
    const first = JSON.stringify(await evaluateEnvelope(fixedInput));
    for (let i = 0; i < 50; i += 1) {
      const next = JSON.stringify(await evaluateEnvelope(fixedInput));
      expect(next).toBe(first);
    }
  });
});
