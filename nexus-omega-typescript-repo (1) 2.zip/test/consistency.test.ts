import { describe, expect, it } from "vitest";
import { deriveConsistency } from "../src/lib/mfcs/consistency.js";

describe("consistency", () => {
  it("fails contradictory state", () => {
    const check = deriveConsistency({
      isValid: true,
      nearRecursion: true,
      phiSatisfied: false,
      deterministic: true,
      idempotent: true
    });
    expect(check.consistency).toBe("FAIL");
    expect(check.reasons).toContain("VALID_AND_NEAR_RECURSIVE_BUT_PHI_FALSE");
  });

  it("passes aligned state", () => {
    const check = deriveConsistency({
      isValid: true,
      nearRecursion: false,
      phiSatisfied: true,
      deterministic: true,
      idempotent: true
    });
    expect(check.consistency).toBe("PASS");
  });
});
