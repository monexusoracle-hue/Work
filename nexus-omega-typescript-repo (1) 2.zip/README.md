# Nexus Omega TypeScript Repo

GitHub-ready TypeScript baseline for a deterministic, invariant-guarded envelope service.

## What is included

- MFCS-inspired deterministic decision kernel
- Envelope evaluation with near-recursion computation
- Consistency guard
- API idempotence check
- Replay harness
- Express API for:
  - `POST /api/v1/envelope/evaluate`
  - `GET /api/v1/envelope/front-report`
  - `GET /omega-api/health`
- Vitest test suite
- TLA+ cross-layer consistency spec
- GitHub Actions CI workflow

## Quick start

```bash
npm install
npm run dev
```

## Build and test

```bash
npm run lint
npm run test
npm run build
```

## API

### POST /api/v1/envelope/evaluate

Request body:

```json
{
  "state": {
    "phi": 0.618,
    "energy": 1.0,
    "nodeDensity": 1.2,
    "stabilityWindow": 2.618,
    "recursionSeed": 4,
    "mode": "BUILD"
  },
  "config": {
    "horizonSteps": 8,
    "epsilon": 0.001,
    "maxEnvelope": 20
  }
}
```

### GET /api/v1/envelope/front-report

Returns the latest evaluation summary and consistency status.

## Why this structure

The repo is organized around deterministic evaluation and consistency discipline:
- the MFCS paper formalizes a strict ring with safety/liveness by construction,
- the Fusion model formalizes positivity, forward invariance, reachability, and boundedness,
- the next operational step is to make runtime behavior repeatable, checkable, and externally consumable.

## Layout

- `src/lib/mfcs/` — kernel, consistency, recursion tests
- `src/lib/omega-api/` — envelope evaluation, types, idempotence, replay
- `src/routes/` — Express route handlers
- `test/` — determinism / idempotence / consistency tests
- `spec/` — TLA+ SystemConsistency spec
- `.github/workflows/` — CI
